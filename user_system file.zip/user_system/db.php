<?php
class DB {
    private static $instance = null;
    private $conn;

    private function __construct() {
        $host = 'localhost';
        $username = 'root';
        $password = '';
        $database = 'user_system';

        mysqli_report(MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

        $this->conn = new mysqli($host, $username, $password, $database);
        $this->conn->set_charset('utf8mb4');
    }

    public static function getInstance() {
        if (self::$instance === null) {
            self::$instance = new DB();
        }
        return self::$instance->conn;
    }
}
?>
