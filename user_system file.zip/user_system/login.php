<?php
require_once 'db.php';
require_once 'repositories/UserRepository.php';
require_once 'repositories/LoginAttemptRepository.php';

session_set_cookie_params([
    'lifetime' => 0,
    'path' => '/',
    'secure' => isset($_SERVER['HTTPS']),
    'httponly' => true,
    'samesite' => 'Strict'
]);
session_start();

// Redirect admin users
if (isset($_SESSION['user']) && $_SESSION['user']['role'] === 'admin') {
    header("Location: admin_dashboard.php");
    exit;
}

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);
$attemptRepo = new LoginAttemptRepository($conn);

$errorMessage = '';
$maxAttempts = 5;
$remainingAttempts = $maxAttempts;

// Handle login submission
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email'] ?? '');
    $password = trim($_POST['password'] ?? '');

    if (empty($email) || empty($password)) {
        $errorMessage = "Please fill in all fields.";
    } else {
        $attempts = $attemptRepo->countRecentAttempts($email);
        $remainingAttempts = $maxAttempts - $attempts;

        if ($attempts >= $maxAttempts) {
            $lastAttempt = $attemptRepo->getLastAttemptTime($email);
            $lockoutTimeLeft = strtotime($lastAttempt) + 900 - time(); // 15 minutes

            if ($lockoutTimeLeft > 0) {
                $errorMessage = "Too many failed attempts. Account locked for " . ceil($lockoutTimeLeft / 60) . " minute(s).";
            } else {
                $attemptRepo->clearAttempts($email);
            }
        }

        // Only continue if not locked
        if ($attempts < $maxAttempts && empty($errorMessage)) {
            $user = $userRepo->getUserByEmail($email);

            if ($user && password_verify($password, $user['password'])) {
                if (!isset($user['is_verified']) || $user['is_verified'] != 1) {
                    $errorMessage = "Your email is not verified. Please check your inbox or use the resend option.";
                } elseif ($user['role'] === 'admin') {
                    $errorMessage = "Admins must log in through the Admin Login page.";
                } else {
                    $attemptRepo->clearAttempts($email);
                    session_regenerate_id(true);
                    $_SESSION['user'] = $user;

                    header("Location: profile.php");
                    exit;
                }
            } else {
                $attemptRepo->logAttempt($email);
                $remainingAttempts--;
                $errorMessage = "Invalid email or password. You have $remainingAttempts attempt(s) remaining.";

                if ($remainingAttempts <= 0) {
                    $errorMessage = "Too many failed attempts. Account locked for 15 minutes.";
                }
            }
        }
    }
}
?>

<!-- HTML LOGIN FORM -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>User Login</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            height: 100vh;
            background-image: url('img/sky.png');
            background-size: cover;
            background-repeat: no-repeat;
            background-position: center;
            background-attachment: fixed;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .container {
            background: rgba(255, 255, 255, 0.95);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
        }
        h2 {
            font-size: 2em;
            margin-bottom: 20px;
        }
        input, button {
            width: 100%;
            margin: 10px 0;
            padding: 12px;
            font-size: 1.1em;
            border: 1px solid #ccc;
            border-radius: 8px;
        }
        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }
        button:hover {
            background-color: #0056b3;
        }
        .error {
            color: red;
            margin-bottom: 15px;
            font-weight: bold;
        }
        p {
            font-size: 1.1em;
        }
        a {
            color: #007BFF;
            text-decoration: none;
        }
        a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>User Login</h2>

    <?php if ($errorMessage): ?>
        <p class="error"><?= htmlspecialchars($errorMessage) ?></p>
    <?php endif; ?>

    <form action="login.php" method="POST">
        <label for="email">Email:</label>
        <input type="email" name="email" id="email" required>

        <label for="password">Password:</label>
        <input type="password" name="password" id="password" required>

        <button type="submit">Login</button>
    </form>

    <p>Don't have an account? <a href="register.php">Register here</a></p>
    <hr>
    <p>Didn't receive the verification email? <br>
        <a href="resend_verification.php">Resend Verification Email</a>
    </p>
    <a href="index.php" style="display: block; margin-top: 15px;">← Back to Home Page</a>
</div>
</body>
</html>
