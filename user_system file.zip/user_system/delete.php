<?php
session_start();

if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}

require_once 'db.php';
require_once 'repositories/UserRepository.php';

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);

$userId = $_SESSION['user']['id'];

// Delete the user and related subscriptions
if ($userRepo->deleteUser($userId)) {
    session_destroy();
    header("Location: index.php?account_deleted=1");
    exit;
} else {
    echo "Error deleting your account. Please try again.";
}
