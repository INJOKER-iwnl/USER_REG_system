<?php
session_start();
require_once 'db.php';
require_once 'repositories/UserRepository.php';

// Admin access check
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Check if ID is provided
if (!isset($_GET['id'])) {
    header("Location: admin.php");
    exit;
}

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);

$id = (int)$_GET['id'];
if ($userRepo->deleteUser($id)) {
    header("Location: admin.php?delete_success=1");
} else {
    header("Location: admin.php?delete_error=1");
}
exit;
?>
