<?php
use PHPUnit\Framework\TestCase;

require_once __DIR__ . '/../repositories/UserRepository.php';

class UserRegisterTest extends TestCase {
    private $connMock;
    private $repo;

    protected function setUp(): void {
        $this->connMock = $this->createMock(mysqli::class);
        $this->repo = new UserRepository($this->connMock);
    }

    public function testCreateUserReturnsTrueOnSuccess() {
        $stmtMock = $this->createMock(mysqli_stmt::class);
        $stmtMock->expects($this->once())->method('bind_param');
        $stmtMock->expects($this->once())->method('execute')->willReturn(true);

        $this->connMock->method('prepare')->willReturn($stmtMock);

        $result = $this->repo->createUser("Alice", "alice@example.com", "hashed123", "token123", "2025-06-10 12:00:00", 1);
        $this->assertTrue($result);
    }

    public function testUpdateVerificationTokenReturnsTrue() {
        $stmtMock = $this->createMock(mysqli_stmt::class);
        $stmtMock->expects($this->once())->method('bind_param');
        $stmtMock->expects($this->once())->method('execute')->willReturn(true);

        $this->connMock->method('prepare')->willReturn($stmtMock);

        $result = $this->repo->updateVerificationToken("alice@example.com", "newToken456", "2025-06-11 12:00:00");
        $this->assertTrue($result);
    }

    public function testGetUnverifiedUsersOver24hReturnsArray() {
        $stmtMock = $this->createMock(mysqli_stmt::class);
        $resultMock = $this->createMock(mysqli_result::class);

        $resultMock->method('fetch_assoc')
            ->willReturnOnConsecutiveCalls(
                ['id' => 1, 'name' => 'Unverified User', 'email' => 'test@demo.com', 'verification_token' => 'abc123'],
                null
            );

        $stmtMock->method('execute');
        $stmtMock->method('get_result')->willReturn($resultMock);

        $this->connMock->method('prepare')->willReturn($stmtMock);

        $result = $this->repo->getUnverifiedUsersOver24h();
        $this->assertCount(1, $result);
        $this->assertEquals('Unverified User', $result[0]['name']);
    }
public function testVerifyTokenValidToken() {
    // First SELECT - token found and not expired
    $stmtMock1 = $this->createMock(mysqli_stmt::class);
    $resultMock1 = $this->createMock(mysqli_result::class);
    $resultMock1->method('fetch_assoc')->willReturn(['id' => 1]);

    $stmtMock1->expects($this->once())->method('bind_param');
    $stmtMock1->expects($this->once())->method('execute');
    $stmtMock1->expects($this->once())->method('get_result')->willReturn($resultMock1);
    $stmtMock1->expects($this->once())->method('close');

    // UPDATE query
    $stmtMock2 = $this->createMock(mysqli_stmt::class);
    $stmtMock2->expects($this->once())->method('bind_param');
    $stmtMock2->expects($this->once())->method('execute');
    $stmtMock2->expects($this->once())->method('close');

    $this->connMock->expects($this->exactly(2))
        ->method('prepare')
        ->willReturnOnConsecutiveCalls($stmtMock1, $stmtMock2);

    $result = $this->repo->verifyToken('validToken');
    $this->assertStringContainsString('✅ Email successfully verified', $result);
}

   public function testVerifyTokenExpiredToken() {
    // First SELECT - token found but expired
    $stmtMock1 = $this->createMock(mysqli_stmt::class);
    $resultMock1 = $this->createMock(mysqli_result::class);
    $resultMock1->method('fetch_assoc')->willReturn(null); // Not found (expired)

    $stmtMock1->expects($this->once())->method('bind_param');
    $stmtMock1->expects($this->once())->method('execute');
    $stmtMock1->expects($this->once())->method('get_result')->willReturn($resultMock1);
    $stmtMock1->expects($this->once())->method('close');

    // Second SELECT - token exists but expired
    $stmtMock2 = $this->createMock(mysqli_stmt::class);
    $resultMock2 = $this->createMock(mysqli_result::class);
    $resultMock2->method('fetch_assoc')->willReturn(['id' => 1]);

    $stmtMock2->expects($this->once())->method('bind_param');
    $stmtMock2->expects($this->once())->method('execute');
    $stmtMock2->expects($this->once())->method('get_result')->willReturn($resultMock2);
    $stmtMock2->expects($this->once())->method('close');

    $this->connMock->expects($this->exactly(2))
        ->method('prepare')
        ->willReturnOnConsecutiveCalls($stmtMock1, $stmtMock2);

    $result = $this->repo->verifyToken('expiredToken');
    $this->assertStringContainsString('❌ Verification link has expired', $result);
}

   public function testVerifyTokenInvalidToken() {
    // First SELECT - token not found at all
    $stmtMock1 = $this->createMock(mysqli_stmt::class);
    $resultMock1 = $this->createMock(mysqli_result::class);
    $resultMock1->method('fetch_assoc')->willReturn(null);

    $stmtMock1->expects($this->once())->method('bind_param');
    $stmtMock1->expects($this->once())->method('execute');
    $stmtMock1->expects($this->once())->method('get_result')->willReturn($resultMock1);
    $stmtMock1->expects($this->once())->method('close');

    // Second SELECT - token also not found (invalid)
    $stmtMock2 = $this->createMock(mysqli_stmt::class);
    $resultMock2 = $this->createMock(mysqli_result::class);
    $resultMock2->method('fetch_assoc')->willReturn(null);

    $stmtMock2->expects($this->once())->method('bind_param');
    $stmtMock2->expects($this->once())->method('execute');
    $stmtMock2->expects($this->once())->method('get_result')->willReturn($resultMock2);
    $stmtMock2->expects($this->once())->method('close');

    $this->connMock->expects($this->exactly(2))
        ->method('prepare')
        ->willReturnOnConsecutiveCalls($stmtMock1, $stmtMock2);

    $result = $this->repo->verifyToken('invalidToken');
    $this->assertStringContainsString('❌ Invalid or already used verification token', $result);
}


    public function testResendVerificationUpdatesToken() {
        $stmtMock = $this->createMock(mysqli_stmt::class);
        $stmtMock->expects($this->once())->method('bind_param');
        $stmtMock->expects($this->once())->method('execute')->willReturn(true);

        $this->connMock->method('prepare')->willReturn($stmtMock);

        $result = $this->repo->updateVerificationToken("resend@example.com", "newtoken123", "2025-06-15 12:00:00");
        $this->assertTrue($result);
    }

    public function testSendVerificationReminderFetchesCorrectUsers() {
        $stmtMock = $this->createMock(mysqli_stmt::class);
        $resultMock = $this->createMock(mysqli_result::class);

        $resultMock->method('fetch_assoc')
            ->willReturnOnConsecutiveCalls(
                ['id' => 2, 'name' => 'Bob', 'email' => 'bob@example.com', 'verification_token' => 'reminder123'],
                null
            );

        $stmtMock->method('execute');
        $stmtMock->method('get_result')->willReturn($resultMock);

        $this->connMock->method('prepare')->willReturn($stmtMock);

        $result = $this->repo->getUnverifiedUsersOver24h();
        $this->assertCount(1, $result);
        $this->assertEquals('bob@example.com', $result[0]['email']);
    }
public function testEmailExistsReturnsTrueWhenFound() {
    $stmtMock = $this->createMock(mysqli_stmt::class);
    $resultMock = $this->createMock(mysqli_result::class);

    $resultMock->method('fetch_assoc')->willReturn(['id' => 1]);

    $stmtMock->expects($this->once())->method('bind_param');
    $stmtMock->expects($this->once())->method('execute');
    $stmtMock->expects($this->once())->method('get_result')->willReturn($resultMock);
    $stmtMock->expects($this->once())->method('close');

    $this->connMock->expects($this->once())
        ->method('prepare')
        ->with("SELECT id FROM users WHERE email = ?")
        ->willReturn($stmtMock);

    $result = $this->repo->emailExists("found@example.com");
    $this->assertTrue($result);
}

public function testEmailExistsReturnsFalseWhenNotFound() {
    $stmtMock = $this->createMock(mysqli_stmt::class);
    $resultMock = $this->createMock(mysqli_result::class);

    $resultMock->method('fetch_assoc')->willReturn(null);

    $stmtMock->expects($this->once())->method('bind_param');
    $stmtMock->expects($this->once())->method('execute');
    $stmtMock->expects($this->once())->method('get_result')->willReturn($resultMock);
    $stmtMock->expects($this->once())->method('close');

    $this->connMock->expects($this->once())
        ->method('prepare')
        ->with("SELECT id FROM users WHERE email = ?")
        ->willReturn($stmtMock);

    $result = $this->repo->emailExists("notfound@example.com");
    $this->assertFalse($result);
}


}