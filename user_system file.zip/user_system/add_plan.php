<?php
session_start();

require_once 'db.php'; // Central DB connection
require_once 'repositories/PlanRepository.php'; // Plan repository

// Admin access check
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Check if form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Collect and sanitize the form data
    $plan_name = trim($_POST['plan_name']);
    $speed = (int)$_POST['speed'];
    $price = (float)$_POST['price'];
    $description = trim($_POST['description']);

    $conn = DB::getInstance();
    $repo = new PlanRepository($conn);

    try {
        $conn->begin_transaction(); // Start transaction

        // Insert plan and get its ID
        $plan_id = $repo->addPlan($plan_name, $speed, $price, $description);

        // Assign plan to all users
        $repo->assignPlanToAllUsers($plan_id);

        $conn->commit(); // Commit transaction
        header("Location: admin.php?msg=Plan added and assigned to users successfully!");
        exit;
    } catch (Exception $e) {
        $conn->rollback(); // Rollback on error
        error_log($e->getMessage());
        echo "❌ Error: Failed to add plan. Please try again.";
    }
}
?>
