<?php
class PlanRepository {
    private $conn;

    public function __construct(mysqli $conn) {
        $this->conn = $conn;
    }

    public function addPlan(string $plan_name, float $speed, float $price, string $description): int|false {
        $stmt = $this->conn->prepare("
            INSERT INTO plans (plan_name, speed, price, description, created_at)
            VALUES (?, ?, ?, ?, NOW())
        ");
        if (!$stmt) {
            error_log("Prepare failed (addPlan): " . $this->conn->error);
            return false;
        }

        $stmt->bind_param("sdds", $plan_name, $speed, $price, $description);
        if ($stmt->execute()) {
            return $this->conn->insert_id;
        } else {
            error_log("Execute failed (addPlan): " . $stmt->error);
        }
        return false;
    }

    public function getAllPlans(): array {
        $result = $this->conn->query("SELECT * FROM plans ORDER BY created_at DESC");
        $plans = [];
        while ($row = $result->fetch_assoc()) {
            $plans[] = $row;
        }
        return $plans;
    }

    public function assignPlanToUser(int $user_id, int $plan_id): bool {
        $stmt = $this->conn->prepare("
            INSERT INTO user_plans (user_id, plan_id, assigned_at)
            VALUES (?, ?, NOW())
        ");
        if (!$stmt) {
            throw new Exception("Prepare failed (assignPlanToUser): " . $this->conn->error);
        }

        $stmt->bind_param("ii", $user_id, $plan_id);
        return $stmt->execute();
    }

    public function assignPlanToAllUsers(int $plan_id): void {
        $result = $this->conn->query("SELECT id FROM users");
        if (!$result) {
            throw new Exception("Failed to fetch users: " . $this->conn->error);
        }

        $stmt = $this->conn->prepare("
            INSERT INTO user_plans (user_id, plan_id, assigned_at)
            VALUES (?, ?, NOW())
        ");
        if (!$stmt) {
            throw new Exception("Prepare failed (assignPlanToAllUsers): " . $this->conn->error);
        }

        while ($row = $result->fetch_assoc()) {
            $user_id = $row['id'];
            $stmt->bind_param("ii", $user_id, $plan_id);
            if (!$stmt->execute()) {
                throw new Exception("Execute failed for user_id $user_id: " . $stmt->error);
            }
        }

        $stmt->close();
    }

    public function deletePlan(int $plan_id): bool {
        $stmt1 = $this->conn->prepare("DELETE FROM user_plans WHERE plan_id = ?");
        $stmt1->bind_param("i", $plan_id);
        $stmt1->execute();

        $stmt2 = $this->conn->prepare("DELETE FROM plans WHERE id = ?");
        $stmt2->bind_param("i", $plan_id);
        return $stmt2->execute();
    }

    public function findPlanById(int $plan_id): ?array {
        $stmt = $this->conn->prepare("SELECT * FROM plans WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $plan_id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function updatePlan(int $id, array $data): bool {
        $stmt = $this->conn->prepare("
            UPDATE plans 
            SET plan_name = ?, speed = ?, price = ?, description = ? 
            WHERE id = ?
        ");
        $stmt->bind_param(
            "sddsi",
            $data['plan_name'],
            $data['speed'],
            $data['price'],
            $data['description'],
            $id
        );
        return $stmt->execute();
    }

    public function getAllUsersWithLatestPlans(): array {
        $sql = "
            SELECT u.id, u.name, u.email, u.role, u.created_at,
                   p.plan_name, p.price, up.assigned_at
            FROM users u
            LEFT JOIN (
                SELECT up1.*
                FROM user_plans up1
                INNER JOIN (
                    SELECT user_id, MAX(assigned_at) AS max_date
                    FROM user_plans
                    GROUP BY user_id
                ) latest ON up1.user_id = latest.user_id AND up1.assigned_at = latest.max_date
            ) up ON u.id = up.user_id
            LEFT JOIN plans p ON up.plan_id = p.id
            ORDER BY u.created_at DESC
        ";

        $users = [];
        $result = $this->conn->query($sql);
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        return $users;
    }
}
?>
