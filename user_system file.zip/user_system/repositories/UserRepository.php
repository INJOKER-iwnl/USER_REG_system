<?php
class UserRepository {
    private mysqli $conn;

    public function __construct(mysqli $conn) {
        $this->conn = $conn;
    }

    public function findByEmail(string $email): ?array {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ? LIMIT 1");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function getUserById($id) {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        return $user;
    }

    public function findById(int $id): ?array {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE id = ? LIMIT 1");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function deleteUser(int $id): bool {
        $stmtPlans = $this->conn->prepare("DELETE FROM user_plans WHERE user_id = ?");
        $stmtPlans->bind_param("i", $id);
        $stmtPlans->execute();

        $stmtUser = $this->conn->prepare("DELETE FROM users WHERE id = ?");
        $stmtUser->bind_param("i", $id);
        return $stmtUser->execute();
    }

    public function verifyAdminCredentials(string $email, string $password): bool|array {
        $user = $this->findByEmail($email);
        if ($user && $user['role'] === 'admin' && password_verify($password, $user['password'])) {
            return $user;
        }
        return false;
    }

    public function getUsers(string $search = '', string $role = '', int $limit = 10, int $offset = 0): array {
        $query = "
            SELECT u.id, u.name, u.email, u.role, u.created_at, u.plan_id, p.plan_name
            FROM users u
            LEFT JOIN plans p ON u.plan_id = p.id
            WHERE 1=1
        ";
        $params = [];
        $types = '';

        if (!empty($search)) {
            $query .= " AND (u.name LIKE ? OR u.email LIKE ?)";
            $searchParam = "%$search%";
            $params[] = $searchParam;
            $params[] = $searchParam;
            $types .= 'ss';
        }

        if (!empty($role)) {
            $query .= " AND u.role = ?";
            $params[] = $role;
            $types .= 's';
        }

        $query .= " ORDER BY u.created_at DESC LIMIT ? OFFSET ?";
        $params[] = $limit;
        $params[] = $offset;
        $types .= 'ii';

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param($types, ...$params);
        $stmt->execute();

        $result = $stmt->get_result();
        $users = [];
        while ($row = $result->fetch_assoc()) {
            $users[] = $row;
        }
        return $users;
    }

    public function countUsers(string $search = '', string $role = ''): int {
        $query = "SELECT COUNT(*) AS total FROM users WHERE 1=1";
        $params = [];
        $types = '';

        if (!empty($search)) {
            $query .= " AND (name LIKE ? OR email LIKE ?)";
            $searchParam = "%$search%";
            $params[] = $searchParam;
            $params[] = $searchParam;
            $types .= 'ss';
        }

        if (!empty($role)) {
            $query .= " AND role = ?";
            $params[] = $role;
            $types .= 's';
        }

        $stmt = $this->conn->prepare($query);
        if (!empty($params)) {
            $stmt->bind_param($types, ...$params);
        }

        $stmt->execute();
        $result = $stmt->get_result();
        return (int) ($result->fetch_assoc()['total'] ?? 0);
    }

    public function getUserByIdWithPlan(int $id): ?array {
        $stmt = $this->conn->prepare("
            SELECT u.*, p.plan_name 
            FROM users u 
            LEFT JOIN plans p ON u.plan_id = p.id 
            WHERE u.id = ? LIMIT 1
        ");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function getUserByEmail(string $email): ?array {
        $stmt = $this->conn->prepare("SELECT * FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        $user = $result->fetch_assoc();
        $stmt->close();
        return $user ?: null;
    }

    public function emailExists($email) {
    $stmt = $this->conn->prepare("SELECT id FROM users WHERE email = ?");
    if (!$stmt) return false;

    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $row = $result->fetch_assoc();

    $stmt->close();  // now safe because result was fully handled before close
    return $row !== null;
}


    public function createUser(string $name, string $email, string $hashedPassword, string $token, string $expiresAt, int $consent): bool {
        $stmt = $this->conn->prepare("
            INSERT INTO users (name, email, password, verification_token, expires_at, is_verified, consent)
            VALUES (?, ?, ?, ?, ?, 0, ?)
        ");
        $stmt->bind_param("sssssi", $name, $email, $hashedPassword, $token, $expiresAt, $consent);
        return $stmt->execute();
    }

    // ✅ New methods for verification email logic
    public function getVerificationData(string $email): ?array {
        $stmt = $this->conn->prepare("SELECT id, name, is_verified, verification_token, expires_at FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function updateVerificationToken(string $email, string $token, string $expires_at): bool {
        $stmt = $this->conn->prepare("UPDATE users SET verification_token = ?, expires_at = ? WHERE email = ?");
        $stmt->bind_param("sss", $token, $expires_at, $email);
        return $stmt->execute();
    }

    public function getUnverifiedUsersOver24h(): array {
    $stmt = $this->conn->prepare("
        SELECT id, name, email, verification_token 
        FROM users 
        WHERE is_verified = 0 
        AND created_at <= NOW() - INTERVAL 24 HOUR 
        AND expires_at > NOW()
    ");
    $stmt->execute();
    $result = $stmt->get_result();

    $users = [];
    while ($row = $result->fetch_assoc()) {
        $users[] = $row;
    }

    return $users;
}

public function updateUserPlan(int $user_id, ?int $plan_id): bool {
    $stmt = $this->conn->prepare("UPDATE users SET plan_id = ? WHERE id = ?");
    $stmt->bind_param("ii", $plan_id, $user_id);
    return $stmt->execute();
}


public function verifyToken(string $token): string {
    $stmt1 = $this->conn->prepare("SELECT * FROM users WHERE verification_token = ? AND expires_at > NOW()");
    if (!$stmt1) {
        return "❌ Database error: Unable to prepare statement";
    }

    $stmt1->bind_param('s', $token);
    $stmt1->execute();
    $result1 = $stmt1->get_result();
    $user = $result1 ? $result1->fetch_assoc() : null;
    $stmt1->close();

    if ($user) {
        $stmt2 = $this->conn->prepare("UPDATE users SET is_verified = 1, verification_token = NULL, expires_at = NULL WHERE verification_token = ?");
        if (!$stmt2) {
            return "❌ Database error: Unable to prepare update statement";
        }

        $stmt2->bind_param('s', $token);
        $stmt2->execute();
        $stmt2->close();

        return "✅ Email successfully verified. <a href='login.php'>Login here</a>.";
    }

    $stmt3 = $this->conn->prepare("SELECT id FROM users WHERE verification_token = ?");
    if (!$stmt3) {
        return "❌ Database error: Unable to prepare statement";
    }

    $stmt3->bind_param('s', $token);
    $stmt3->execute();
    $result3 = $stmt3->get_result();
    $found = $result3 && $result3->fetch_assoc();
    $stmt3->close();

    return $found
        ? "❌ Verification link has expired"
        : "❌ Invalid or already used verification token";
}

}