<?php
class LoginAttemptRepository {
    private mysqli $conn;

    public function __construct(mysqli $conn) {
        $this->conn = $conn;
    }

    public function countRecentAttempts(string $email): int {
        $stmt = $this->conn->prepare("
            SELECT COUNT(*) 
            FROM login_attempts 
            WHERE email = ? 
            AND attempt_time > (NOW() - INTERVAL 15 MINUTE)
        ");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($count);
        $stmt->fetch();
        $stmt->close();
        return $count;
    }

    public function logAttempt(string $email): void {
        $stmt = $this->conn->prepare("INSERT INTO login_attempts (email) VALUES (?)");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->close();
    }

    public function clearAttempts(string $email): void {
        $stmt = $this->conn->prepare("DELETE FROM login_attempts WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->close();
    }

    public function getLastAttemptTime(string $email): ?string {
        $stmt = $this->conn->prepare("SELECT MAX(attempt_time) FROM login_attempts WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->bind_result($last);
        $stmt->fetch();
        $stmt->close();
        return $last ?: null;
    }
}
?>
