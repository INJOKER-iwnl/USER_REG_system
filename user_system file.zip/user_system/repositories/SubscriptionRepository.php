<?php
class SubscriptionRepository {
    private mysqli $conn;

    public function __construct(mysqli $conn) {
        $this->conn = $conn;
    }

    public function getSubscriptionById(int $subscriptionId, int $userId, bool $includeCancelled = false): ?array {
        $query = "SELECT * FROM subscriptions WHERE id = ? AND user_id = ?";
        if (!$includeCancelled) {
            $query .= " AND cancelled_at IS NULL";
        }

        $stmt = $this->conn->prepare($query);
        $stmt->bind_param("ii", $subscriptionId, $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $subscription = $result->fetch_assoc();

        if (!$subscription) {
            error_log("Subscription not found or cancelled (ID: $subscriptionId, User: $userId)");
        }

        return $subscription ?: null;
    }

    public function cancelSubscription(int $subscriptionId, int $userId): bool {
        $cancelTime = date('Y-m-d H:i:s');
        $stmt = $this->conn->prepare("
            UPDATE subscriptions 
            SET cancelled_at = ?, status = 'cancelled' 
            WHERE id = ? AND user_id = ? AND cancelled_at IS NULL
        ");
        $stmt->bind_param("sii", $cancelTime, $subscriptionId, $userId);
        $success = $stmt->execute();

        if ($success && $stmt->affected_rows > 0) {
            $this->logAction($userId, 'cancel_subscription', "Cancelled subscription ID $subscriptionId at $cancelTime");
        }

        return $success && $stmt->affected_rows > 0;
    }

    public function updateSubscriptionPlan(int $subscriptionId, int $userId, int $newPlanId): bool {
        $stmt = $this->conn->prepare("
            UPDATE subscriptions 
            SET plan_id = ? 
            WHERE id = ? AND user_id = ? AND cancelled_at IS NULL
        ");
        $stmt->bind_param("iii", $newPlanId, $subscriptionId, $userId);
        $success = $stmt->execute();

        if ($success && $stmt->affected_rows > 0) {
            $this->logAction($userId, 'update_plan', "Updated subscription ID $subscriptionId to plan ID $newPlanId");
        }

        return $success && $stmt->affected_rows > 0;
    }

    public function getUserSubscriptions(int $userId): array {
        $stmt = $this->conn->prepare("
            SELECT * FROM subscriptions 
            WHERE user_id = ? AND cancelled_at IS NULL
            ORDER BY subscribed_at DESC
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();

        $subscriptions = [];
        while ($row = $result->fetch_assoc()) {
            $subscriptions[] = $row;
        }

        return $subscriptions;
    }

    public function getActiveSubscriptionByPlan(int $userId, int $planId): ?array {
        $stmt = $this->conn->prepare("
            SELECT * FROM subscriptions 
            WHERE user_id = ? AND plan_id = ? AND cancelled_at IS NULL
            ORDER BY subscribed_at DESC 
            LIMIT 1
        ");
        $stmt->bind_param("ii", $userId, $planId);
        $stmt->execute();
        $result = $stmt->get_result();
        return $result->fetch_assoc() ?: null;
    }

    public function getSubscriptionByUserId(int $userId): ?array {
        $stmt = $this->conn->prepare("
            SELECT s.*, p.plan_name, p.speed, p.price, p.description 
            FROM subscriptions s 
            JOIN plans p ON s.plan_id = p.id 
            WHERE s.user_id = ? AND s.cancelled_at IS NULL 
            ORDER BY s.subscribed_at DESC 
            LIMIT 1
        ");
        $stmt->bind_param("i", $userId);
        $stmt->execute();
        $result = $stmt->get_result();
        $subscription = $result->fetch_assoc();
        $stmt->close();
        return $subscription ?: null;
    }

    private function logAction(int $userId, string $action, string $details): void {
        $stmt = $this->conn->prepare("
            INSERT INTO audit_logs (user_id, action, details)
            VALUES (?, ?, ?)
        ");
        $stmt->bind_param("iss", $userId, $action, $details);
        $stmt->execute();
    }
}
