<?php
echo password_hash("Punam10@10", PASSWORD_DEFAULT);
