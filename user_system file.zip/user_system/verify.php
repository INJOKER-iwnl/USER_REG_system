<?php
require_once 'db.php';
require_once 'repositories/UserRepository.php';

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);

$token = $_GET['token'] ?? '';

if ($token) {
    echo $userRepo->verifyToken($token);
} else {
    echo "❌ No token provided.";
}
