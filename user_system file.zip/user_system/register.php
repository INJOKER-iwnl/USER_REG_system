<?php
require_once 'db.php';
require_once 'repositories/UserRepository.php';

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$consent = isset($_POST['consent']) ? 1 : 0;

$error_message = '';
$success_message = '';

$passwordPattern = '/^(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!$consent) {
        $error_message = "You must agree to the data usage policy to register.";
    } elseif (empty($name) || empty($email) || empty($password)) {
        $error_message = "All fields are required. Please fill in all details.";
    } elseif (!preg_match($passwordPattern, $password)) {
        $error_message = "Password must contain at least one uppercase letter, one special character, and be at least 8 characters long.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error_message = "Invalid email format. Please enter a valid email address.";
    } elseif ($userRepo->emailExists($email)) {
        $error_message = "Email is already registered. Please use a different email.";
    } else {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $token = bin2hex(random_bytes(32));
        $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));

        if ($userRepo->createUser($name, $email, $hashedPassword, $token, $expires_at, $consent)) {
            $base_url = "https://172.20.10.2/user_system";
            $verify_link = "$base_url/verify.php?token=" . urlencode($token);

            $subject = "Confirm Your Email";
            $message = "Hi $name,\n\nPlease click the link below to verify your email within 24 hours:\n$verify_link\n\nIf the link expires, you can request a new one.";
            $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'];

            if (mail($email, $subject, $message, $headers)) {
                $success_message = "Registration successful! A confirmation email has been sent.";
                $name = $email = $password = '';
            } else {
                $error_message = "Could not send confirmation email.";
            }
        } else {
            $error_message = "Something went wrong during registration.";
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register</title>
  <style>
    * { box-sizing: border-box; }
    body {
      font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
      background-image: url('img/sky.png');
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      background-attachment: fixed;
      margin: 0;
      padding: 0;
      display: flex;
      justify-content: center;
      align-items: center;
      height: 100vh;
      color: #333;
    }
    .container {
      background: white;
      padding: 40px;
      border-radius: 16px;
      box-shadow: 0 10px 30px rgba(0, 0, 0, 0.2);
      width: 100%;
      max-width: 420px;
      text-align: center;
    }
    h2 {
      margin-bottom: 24px;
      font-size: 1.8rem;
      color: #333;
    }
    form { text-align: left; }
    label {
      font-weight: bold;
      margin-top: 12px;
      display: block;
    }
    input[type="text"],
    input[type="email"],
    input[type="password"] {
      width: 100%;
      padding: 12px;
      margin-top: 6px;
      margin-bottom: 16px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 1rem;
      transition: border 0.3s;
    }
    input:focus,
    button:focus-visible {
      border: 2px solid #2575fc;
      outline: 3px solid #8ab4f8;
      outline-offset: 1px;
    }
    .password-info {
      font-size: 0.85rem;
      color: #666;
      margin-top: -12px;
      margin-bottom: 20px;
    }
    .checkbox-label {
      font-size: 0.9rem;
      margin-top: 8px;
      display: flex;
      align-items: center;
    }
    .checkbox-label input {
      margin-right: 8px;
    }
    button {
      width: 100%;
      padding: 12px;
      background-color: #2575fc;
      border: none;
      color: white;
      font-size: 1rem;
      border-radius: 8px;
      cursor: pointer;
      transition: background-color 0.3s ease;
    }
    button:hover {
      background-color: #1a5fd7;
    }
    .error-message,
    .success-message {
      font-weight: bold;
      margin-bottom: 15px;
      padding: 10px;
      border-radius: 8px;
    }
    .error-message {
      color: #721c24;
      background-color: #f8d7da;
    }
    .success-message {
      color: #155724;
      background-color: #d4edda;
    }
    .links {
      margin-top: 20px;
      font-size: 0.95rem;
    }
    .links a {
      color: #2575fc;
      text-decoration: none;
    }
    .links a:hover {
      text-decoration: underline;
    }
    .visually-hidden {
      position: absolute;
      width: 1px;
      height: 1px;
      margin: -1px;
      border: 0;
      padding: 0;
      clip: rect(0 0 0 0);
      overflow: hidden;
    }
  </style>
</head>
<body>
<main role="main" aria-labelledby="registerHeading">
  <div class="container">
    <h2 id="registerHeading">Create Your Account</h2>

    <?php if ($error_message): ?>
      <div class="error-message" role="alert" aria-live="polite"><?= htmlspecialchars($error_message) ?></div>
    <?php elseif ($success_message): ?>
      <div class="success-message" role="status" aria-live="polite"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>

    <form action="register.php" method="POST" role="form" aria-describedby="formDesc">
      <p id="formDesc" class="visually-hidden">Use this form to create an account. All fields are required.</p>

      <label for="name">Full Name</label>
      <input type="text" id="name" name="name" value="<?= htmlspecialchars($name) ?>" required aria-required="true" />

      <label for="email">Email Address</label>
      <input type="email" id="email" name="email" value="<?= htmlspecialchars($email) ?>" required aria-required="true" />

      <label for="password">Password</label>
      <input type="password" id="password" name="password" required aria-required="true" aria-describedby="passwordHelp" />
      <p id="passwordHelp" class="password-info">
        Must contain at least one uppercase letter, one special character, and be 8+ characters long.
      </p>

      <label class="checkbox-label" for="consent">
        <input type="checkbox" name="consent" id="consent" required />
        I agree to the collection and use of my data for account registration and subscription services.
      </label>

      <button type="submit">Register</button>
    </form>

    <div class="links">
      <p>Already have an account? <a href="login.php">Login here</a></p>
      <p><a href="index.php">← Back to Home Page</a></p>
    </div>
  </div>
</main>
</body>
</html>