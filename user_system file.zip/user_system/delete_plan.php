<?php
// delete_plan.php
session_start();

require_once 'db.php';
require_once 'repositories/PlanRepository.php';

// Admin access check
if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$conn = DB::getInstance();
$planRepo = new PlanRepository($conn);

// Check if a plan ID is provided
if (isset($_GET['id'])) {
    $plan_id = (int)$_GET['id'];

    // Delete plan from both `user_plans` and `plans` tables
    if ($planRepo->deletePlan($plan_id)) {
        // Also reset users who had this plan as their current one
        $stmt = $conn->prepare("UPDATE users SET plan_id = NULL WHERE plan_id = ?");
        $stmt->bind_param("i", $plan_id);
        $stmt->execute();

        header("Location: admin.php?msg=Plan deleted and removed from user records!");
        exit;
    } else {
        echo "Error: Failed to delete plan.";
    }
} else {
    echo "No plan ID provided.";
}
?>
