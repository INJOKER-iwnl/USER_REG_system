<?php
session_start();

require_once 'db.php';              // Singleton DB connection
require_once 'repositories/UserRepository.php'; // Repository class

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);

$feedback = '';
$feedback_class = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = trim($_POST['email']);

    if (empty($email)) {
        $feedback = 'Email is required.';
        $feedback_class = 'error';
    } else {
        $user = $userRepo->getVerificationData($email);

        if (!$user) {
            $feedback = 'No account found with that email.';
            $feedback_class = 'error';
        } elseif ((int)$user['is_verified'] === 1) {
            $feedback = 'Your email is already verified.';
            $feedback_class = 'message';
        } else {
            $token = $user['verification_token'];
            $generate_new_token = false;

            if ($user['expires_at'] && strtotime($user['expires_at']) <= time()) {
                $generate_new_token = true;
                $token = bin2hex(random_bytes(32));
                $expires_at = date('Y-m-d H:i:s', strtotime('+24 hours'));

                $userRepo->updateVerificationToken($email, $token, $expires_at);
            }

            $base_url = "http://172.20.10.2/user_system";
            $verify_link = "$base_url/verify.php?token=" . urlencode($token);

            $subject = "Resend: Confirm Your Email";
            $message = "Hi " . htmlspecialchars($user['name']) . ",\n\n";
            $message .= "Please click the link below to verify your email within 24 hours:\n$verify_link\n\n";
            $message .= "If you did not request this, you can safely ignore it.\n\nThanks.";

            $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'];

            if (mail($email, $subject, $message, $headers)) {
                $feedback = 'Verification email resent successfully. Please check your inbox.';
                $feedback_class = 'message';
            } else {
                $feedback = 'Could not send email. Please try again later.';
                $feedback_class = 'error';
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Resend Verification Email</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-image: url('img/sky.png');
            background-size: cover;
            background-position: center;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background: rgba(231, 227, 227, 0.96);
            padding: 40px;
            border-radius: 15px;
            box-shadow: 0 0 20px rgba(0, 0, 0, 0.3);
            width: 400px;
            text-align: center;
        }

        h2 {
            margin-bottom: 20px;
        }

        input, button {
            width: 100%;
            padding: 12px;
            margin: 10px 0;
            border-radius: 8px;
            font-size: 1em;
            border: 1px solid #ccc;
        }

        button {
            background-color: #007BFF;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }

        .message {
            margin-top: 15px;
            font-weight: bold;
            color: green;
        }

        .error {
            color: red;
            margin-top: 15px;
        }

        a {
            text-decoration: none;
            display: block;
            margin-top: 15px;
            color: #007BFF;
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Resend Verification Email</h2>

    <?php if (!empty($feedback)): ?>
        <p class="<?= $feedback_class ?>"><?= htmlspecialchars($feedback) ?></p>
    <?php endif; ?>

    <form action="" method="POST">
        <input type="email" name="email" placeholder="Enter your email" required>
        <button type="submit">Send Verification Link</button>
    </form>
    <a href="login.php">← Back to Login</a>
</div>
</body>
</html>
