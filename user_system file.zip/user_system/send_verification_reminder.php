<?php
// send_verification_reminders.php

require_once 'db.php';
require_once 'repositories/UserRepository.php';

$conn = DB::getInstance();
$userRepo = new UserRepository($conn);

// Get unverified users registered over 24 hours ago
$users = $userRepo->getUnverifiedUsersOver24h();

$base_url = "http://172.20.10.2/user_system"; // update IP if needed
$sent_count = 0;

foreach ($users as $user) {
    $verify_link = "$base_url/verify.php?token=" . urlencode($user['verification_token']);

    $subject = "Reminder: Verify Your Email";
    $message = "Hi " . htmlspecialchars($user['name']) . ",\n\n";
    $message .= "You registered an account with us, but your email is not yet verified.\n";
    $message .= "Please click the link below to verify your email within 24 hours:\n$verify_link\n\n";
    $message .= "If you did not register, please ignore this email.\n\nThanks.";

    $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'];

    if (mail($user['email'], $subject, $message, $headers)) {
        $sent_count++;
    }
}

echo "Sent $sent_count verification reminders.";
