<?php
echo password_hash("Admin10@100", PASSWORD_DEFAULT);
