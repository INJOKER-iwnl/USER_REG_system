<?php
// index.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>FiberNet | Home</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        /* Reset and base styles */
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6;
            background-color: #f9fafc;
            color: #333;
        }

        /* Header */
        .header {
            background-color: #004466;
            padding: 20px 40px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .logo {
            font-size: 24px;
            color: #fff;
            font-weight: bold;
        }

        .navbar a {
            text-decoration: none;
            margin-left: 15px;
            padding: 10px 18px;
            border-radius: 4px;
            font-weight: bold;
            display: inline-block;
            transition: transform 0.3s ease, background-color 0.3s ease;
        }

        .nav-button {
            background-color: #d62828; /* Red */
            color: #fff;
        }

        .nav-button:hover {
            background-color: #a61b1b; /* Darker red */
            transform: scale(1.05);
        }

        /* Hero Section */
        .hero {
            background: linear-gradient(to right, #004466, #0077aa);
            color: #fff;
            text-align: center;
            padding: 100px 20px 60px;
        }

        .hero h1 {
            font-size: 3rem;
            margin-bottom: 20px;
        }

        .hero p {
            font-size: 1.2rem;
        }

        /* Plan Cards */
        .plans {
            max-width: 1200px;
            margin: 50px auto;
            padding: 0 20px;
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 30px;
        }

        .plan-card {
            background: #fff;
            border-radius: 10px;
            box-shadow: 0 6px 18px rgba(0, 0, 0, 0.05);
            padding: 30px 20px;
            text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }

        .plan-card:hover {
            transform: translateY(-8px);
            box-shadow: 0 12px 30px rgba(0, 0, 0, 0.08);
        }

        .plan-card h3 {
            color: #004466;
            margin-bottom: 10px;
        }

        .price {
            font-size: 28px;
            font-weight: bold;
            color: #0077aa;
            margin: 10px 0;
        }

        .features {
            list-style: none;
            padding: 0;
            margin-bottom: 20px;
        }

        .features li {
            padding: 8px 0;
            border-bottom: 1px solid #eee;
        }

        .button {
            display: inline-block;
            background-color: #0077aa;
            color: #fff;
            padding: 10px 22px;
            border-radius: 25px;
            text-decoration: none;
            transition: background 0.3s;
        }

        .button:hover {
            background-color: #005f8a;
        }

        /* Footer */
        .footer {
            background-color: #004466;
            color: #fff;
            text-align: center;
            padding: 20px 0;
            margin-top: 50px;
        }

        @media (max-width: 600px) {
            .hero h1 {
                font-size: 2rem;
            }
        }
    </style>
</head>
<body>

    <!-- Header and Nav -->
    <header class="header">
        <div class="logo">Piethonet</div>
        <nav class="navbar">
            <a href="admin_login.php" class="nav-button">🔒 Admin Login</a>
            <a href="login.php" class="nav-button">👤 User Login</a>
            <a href="register.php" class="nav-button">📝 Register</a>
        </nav>
    </header>

    <!-- Hero Section -->
    <section class="hero">
        <h1>Fast. Reliable. Affordable Internet.</h1>
        <p>Explore our flexible plans and experience seamless connectivity.</p>
        <p>please make account and login to subscribe our plan.</p>
    </section>

    <!-- Plans Section -->
    <section class="plans">
        <div class="plan-card">
            <h3>Basic Plan</h3>
            <p class="price">$10/month</p>
            <ul class="features">
                <li>Speed: 25 Mbps</li>
                <li>Unlimited Data</li>
                <li>Free Installation</li>
                <li>Email Support</li>
            </ul>
            
        </div>

        <div class="plan-card">
            <h3>Standard Plan</h3>
            <p class="price">$25/month</p>
            <ul class="features">
                <li>Speed: 100 Mbps</li>
                <li>Unlimited Data</li>
                <li>Router Included</li>
                <li>Phone & Email Support</li>
            </ul>
            
        </div>

        <div class="plan-card">
            <h3>Premium Plan</h3>
            <p class="price">$50/month</p>
            <ul class="features">
                <li>Speed: 500 Mbps</li>
                <li>Unlimited Data</li>
                <li>Free Upgrade Options</li>
                <li>24/7 VIP Support</li>
            </ul>
           
        </div>
    </section>

    <!-- Footer -->
    <footer class="footer">
        &copy; <?php echo date("Y"); ?> Piethonet. All rights reserved.
    </footer>

</body>
</html>

