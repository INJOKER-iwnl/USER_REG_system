<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.html");
    exit;
}

$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) die("Connection failed");

$id = $_SESSION['user']['id'];
$success = "";
$error = "";

// Fetch user data
$stmt = $conn->prepare("SELECT * FROM users WHERE id=?");
$stmt->bind_param("i", $id);
$stmt->execute();
$result = $stmt->get_result();
$user = $result->fetch_assoc();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $name = trim($_POST['name']);
    $email = trim($_POST['email']);
    $old_password = $_POST['old_password'] ?? '';
    $new_password = $_POST['new_password'] ?? '';
    $confirm_password = $_POST['confirm_password'] ?? '';

    // Check if user changed profile info or wants to change password
    $changing_profile = ($name !== $user['name'] || $email !== $user['email']);
    $changing_password = (!empty($new_password) || !empty($confirm_password));

    // Require current password if changing profile or password
    if (($changing_profile || $changing_password) && empty($old_password)) {
        $error = "❌ Current password is required to make changes.";
    } elseif (!empty($old_password) && !password_verify($old_password, $user['password'])) {
        $error = "❌ Current password is incorrect.";
    }

    if (!$error) {
        // Update profile if changed
        if ($changing_profile) {
            $stmt = $conn->prepare("UPDATE users SET name=?, email=? WHERE id=?");
            $stmt->bind_param("ssi", $name, $email, $id);
            if ($stmt->execute()) {
                $_SESSION['user']['name'] = $name;
                $_SESSION['user']['email'] = $email;
                $success = "✅ Profile updated successfully!";
            } else {
                $error = "❌ Failed to update profile.";
            }
        }

        // Update password if requested
        if ($changing_password) {
            if ($new_password !== $confirm_password) {
                $error = "❌ New passwords do not match.";
            } else {
                $hashed = password_hash($new_password, PASSWORD_DEFAULT);
                $stmt = $conn->prepare("UPDATE users SET password=? WHERE id=?");
                $stmt->bind_param("si", $hashed, $id);
                if ($stmt->execute()) {
                    $success .= " 🔐 Password updated successfully.";
                } else {
                    $error = "❌ Failed to update password.";
                }
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8" />
    <title>Update Profile</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background: #f0f4f8;
            margin: 0; padding: 0;
            display: flex;
            justify-content: center;
            padding: 60px 20px;
        }
        .container {
            background: #fff;
            padding: 40px 50px;
            border-radius: 16px;
            box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            width: 100%;
            max-width: 600px;
        }
        h2 {
            text-align: center;
            color: #2c3e50;
            margin-bottom: 30px;
        }
        form {
            display: flex;
            flex-direction: column;
        }
        label {
            margin-bottom: 5px;
            font-weight: 500;
            color: #333;
        }
        input[type="text"],
        input[type="email"],
        input[type="password"] {
            padding: 12px;
            border: 1px solid #ccc;
            border-radius: 8px;
            margin-bottom: 20px;
            font-size: 15px;
        }
        button {
            padding: 14px;
            background-color: #00bcd4;
            color: white;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: bold;
            cursor: pointer;
            transition: background 0.3s ease;
        }
        button:hover {
            background-color: #0097a7;
        }
        .message {
            padding: 12px 16px;
            border-radius: 8px;
            margin-bottom: 20px;
            font-weight: 500;
        }
        .success {
            background-color: #e8f5e9;
            color: #2e7d32;
            border: 1px solid #c8e6c9;
        }
        .error {
            background-color: #ffebee;
            color: #c62828;
            border: 1px solid #ffcdd2;
        }
        hr {
            border: none;
            border-top: 1px solid #e0e0e0;
            margin: 30px 0;
        }
        a {
            text-align: center;
            display: block;
            margin-top: 25px;
            text-decoration: none;
            color: #00bcd4;
            font-weight: 500;
        }
        a:hover {
            text-decoration: underline;
        }
        @media (max-width: 500px) {
            .container {
                padding: 30px 20px;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h2>Update Your Profile</h2>

    <?php if ($success): ?>
        <div class="message success"><?php echo $success; ?></div>
    <?php endif; ?>

    <?php if ($error): ?>
        <div class="message error"><?php echo $error; ?></div>
    <?php endif; ?>

    <form method="POST" action="">
        <label for="name">Full Name</label>
        <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($user['name']); ?>" required />

        <label for="email">Email Address</label>
        <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" required />

        <hr />

        <label for="old_password">Current Password</label>
       <input type="password" name="old_password" id="old_password" placeholder="Enter your current password" value="" autocomplete="new-password" />


        <label for="new_password">New Password</label>
        <input type="password" name="new_password" id="new_password" placeholder="Enter a new password" value="" />

        <label for="confirm_password">Confirm New Password</label>
        <input type="password" name="confirm_password" id="confirm_password" placeholder="Confirm your new password" value="" />

        <button type="submit">Save Changes</button>
    </form>

    <a href="profile.php">← Back to Profile</a>
</div>
</body>
</html>
