<?php
// Enable error reporting for debugging
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

session_start();

// Check if user is logged in
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit();
}

$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$errorMsg = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user']['id'];

    // Handle Subscribe action
    if (isset($_POST['plan_id'])) {
        $plan_id = intval($_POST['plan_id']);

        // Check for existing subscription
        $check = $conn->prepare("SELECT * FROM subscriptions WHERE user_id = ?");
        $check->bind_param("i", $user_id);
        $check->execute();
        $existing = $check->get_result();

        if ($existing->num_rows > 0) {
            // Update existing subscription
            $stmt = $conn->prepare("UPDATE subscriptions SET plan_id = ?, subscribed_at = NOW() WHERE user_id = ?");
            $stmt->bind_param("ii", $plan_id, $user_id);
        } else {
            // Insert new subscription
            $stmt = $conn->prepare("INSERT INTO subscriptions (user_id, plan_id) VALUES (?, ?)");
            $stmt->bind_param("ii", $user_id, $plan_id);
        }

        // Also update the user's plan_id in the users table
        $updateUser = $conn->prepare("UPDATE users SET plan_id = ? WHERE id = ?");
        $updateUser->bind_param("ii", $plan_id, $user_id);

        if ($stmt->execute() && $updateUser->execute()) {
            $_SESSION['user']['plan_id'] = $plan_id; // Update session

            $stmt->close();
            $updateUser->close();
            $check->close();
            $conn->close();

            header("Location: profile.php?message=Subscription+updated+successfully");
            exit();
        } else {
            $errorMsg = "Error updating subscription: " . $stmt->error . " | " . $updateUser->error;
            $stmt->close();
            $updateUser->close();
            $check->close();
        }
    }
    // Handle Cancel action
    elseif (isset($_POST['action']) && strpos($_POST['action'], 'cancel_') === 0) {
        $planId = intval(substr($_POST['action'], 7));

        $stmt = $conn->prepare("DELETE FROM subscriptions WHERE user_id = ? AND plan_id = ?");
        $stmt->bind_param("ii", $user_id, $planId);

        if ($stmt->execute()) {
            // Also update users.plan_id to NULL
            $updateUser = $conn->prepare("UPDATE users SET plan_id = NULL WHERE id = ?");
            $updateUser->bind_param("i", $user_id);
            $updateUser->execute();
            $updateUser->close();

            $_SESSION['user']['plan_id'] = null; // Update session

            $stmt->close();
            $conn->close();

            header("Location: profile.php?message=Subscription+canceled+successfully");
            exit();
        } else {
            $errorMsg = "Error canceling subscription: " . $stmt->error;
            $stmt->close();
        }
    }
    // Handle Edit action (redirect to edit page)
    elseif (isset($_POST['action']) && strpos($_POST['action'], 'edit_') === 0) {
        $planId = intval(substr($_POST['action'], 5));
        $conn->close();
        header("Location: edit_subscription.php?plan_id=$planId");
        exit();
    } else {
        $errorMsg = "Invalid action.";
    }
} else {
    $errorMsg = "Invalid request method.";
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Subscription Update</title>
    <style>
        body {
            margin: 0;
            padding: 0;
            font-family: Arial, sans-serif;
            background-image: url('img/kathmandu.jpg');
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-position: center;
            color: #fff;
        }

        .content {
            background-color: rgba(0, 0, 0, 0.6);
            max-width: 600px;
            margin: 100px auto;
            padding: 30px;
            border-radius: 12px;
            text-align: center;
        }

        h1 {
            color: #00ffcc;
        }

        p {
            font-size: 18px;
        }

        a {
            color: #00ccff;
            text-decoration: none;
            font-weight: bold;
        }

        a:hover {
            text-decoration: underline;
        }

        .error {
            color: #ff4444;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="content">
        <h1>Subscription Status</h1>
        <?php if ($errorMsg): ?>
            <p class="error"><?= htmlspecialchars($errorMsg) ?></p>
            <p><a href="profile.php">Go back to Profile</a></p>
        <?php else: ?>
            <p>Processing...</p>
        <?php endif; ?>
    </div>
</body>
</html>
