<?php
$conn = new mysqli("localhost", "root", "", "user_system");
if ($conn->connect_error) die("Connection failed");

$name = $_POST['name'] ?? '';
$email = $_POST['email'] ?? '';
$password = $_POST['password'] ?? '';
$error_message = '';
$success_message = '';

$passwordPattern = '/^(?=.*[A-Z])(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!preg_match($passwordPattern, $password)) {
        $error_message = "Password must contain at least one uppercase letter, one special character, and be at least 8 characters long.";
    }

    if (!$error_message) {
        $check = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $check->bind_param("s", $email);
        $check->execute();
        $check->store_result();

        if ($check->num_rows > 0) {
            $error_message = "Email is already registered. Please use a different email.";
        }
        $check->close();  
    }

    if (!$error_message) {
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $token = bin2hex(random_bytes(32));
        $stmt = $conn->prepare("INSERT INTO users (name, email, password, verification_token, is_verified) VALUES (?, ?, ?, ?, 0)");
        $stmt->bind_param("ssss", $name, $email, $hashedPassword, $token);

        if ($stmt->execute()) {
            // Set your correct project folder name here
            $base_url = "http://10.37.72.47/user_system";
            $verify_link ="$base_url/verify.php?token=" . urlencode($token);


            $subject = "Confirm Your Email";
            $message = "Hi $name,\n\nPlease click the link below to verify your email:\n$verify_link";
            $headers = "From: no-reply@" . $_SERVER['HTTP_HOST'];

            if (mail($email, $subject, $message, $headers)) {
                $success_message = "Registration successful! A confirmation email has been sent to your address.";
                $name = $email = $password = '';
            } else {
                $error_message = "Could not send confirmation email.";
            }
        } else {
            $error_message = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <title>Register</title>
  <link rel="stylesheet" href="style.css">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: Arial, sans-serif;
      height: 100vh;
      background-image: url('img/bg.jpeg');
      background-size: cover;
      background-repeat: no-repeat;
      background-position: center;
      background-attachment: fixed;
      display: flex;
      justify-content: center;
      align-items: center;
    }
    .container {
      background: rgba(230, 226, 226, 0.95);
      padding: 40px;
      border-radius: 15px;
      box-shadow: 0 0 20px rgba(0, 0, 0, 0.4);
      width: 400px;
      text-align: center;
    }
    h2 {
      font-size: 2em;
      margin-bottom: 20px;
    }
    input, button {
      width: 100%;
      margin: 15px 0;
      padding: 12px;
      font-size: 1.1em;
    }
    .error-message {
      color: red;
      margin-bottom: 15px;
      font-weight: bold;
    }
    .success-message {
      color: green;
      margin-bottom: 15px;
      font-weight: bold;
    }
    .password-info {
      font-size: 0.9em;
      color: #888;
      margin-top: -10px;
      margin-bottom: 20px;
      text-align: left;
    }
    p {
      font-size: 1.1em;
    }
    a {
      color: #007BFF;
      text-decoration: none;
    }
    a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Register</h2>

  <?php if ($error_message): ?>
    <p class="error-message"><?= htmlspecialchars($error_message) ?></p>
  <?php elseif ($success_message): ?>
    <p class="success-message"><?= htmlspecialchars($success_message) ?></p>
  <?php endif; ?>

  <form action="register.php" method="POST">
    <input type="text" name="name" placeholder="Full Name" value="<?= htmlspecialchars($name) ?>" required>
    <input type="email" name="email" placeholder="Email" value="<?= htmlspecialchars($email) ?>" required>
    <input type="password" name="password" placeholder="Password" required>
    <p class="password-info">
      Password must contain at least one uppercase letter, one special character, and be at least 8 characters long.
    </p>
    <button type="submit">Register</button>
  </form>

  <p>Already have an account? <a href="login.php">Login here</a></p>
  <a href="index.php" style="display: block; margin-top: 15px;">← Back to Home Page</a>
</div>

</body>
</html>
